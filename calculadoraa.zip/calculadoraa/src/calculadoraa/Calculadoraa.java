/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadoraa;

import javax.swing.JOptionPane;

/**
 *k
 * @author bryan
 */
public class Calculadoraa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double numero1,numero2,resultado=0;
        int opcion;
        opcion=Integer.parseInt(JOptionPane.showInputDialog("elija una opcion \n 1-suma  \n 2-resta  \n 3-multiplicacion  \n 4-divicion \n 5-salir "));
        while(opcion==1 || opcion==2 || opcion==3 || opcion==4){
            switch (opcion) {
                case 1:
                    numero1=Double.parseDouble(JOptionPane.showInputDialog("ingrese el primer numero"));
                    do{
                        numero2=Double.parseDouble(JOptionPane.showInputDialog("ingrese el segundo numero"));
                    }while(numero2 == 0);
                    resultado=numero1+numero2;
                    JOptionPane.showMessageDialog(null,"el resultado es:"+ resultado);
                    break;
                case 2:
                    numero1=Double.parseDouble(JOptionPane.showInputDialog("ingrese el primer numero"));
                    do{
                        numero2=Double.parseDouble(JOptionPane.showInputDialog("ingrese el segundo numero"));
                    }while(numero2 == 0);
                    resultado=numero1-numero2;
                    JOptionPane.showMessageDialog(null,"el resultado es:"+ resultado);
                    break;
                case 3:
                    numero1=Double.parseDouble(JOptionPane.showInputDialog("ingrese el primer numero"));
                    do{
                        numero2=Double.parseDouble(JOptionPane.showInputDialog("ingrese el segundo numero"));
                    }while(numero2 == 0);
                    resultado=numero1*numero2;
                    JOptionPane.showMessageDialog(null,"el resultado es:"+ resultado);
                    break;
                case 4:
                    numero1=Double.parseDouble(JOptionPane.showInputDialog("ingrese el primer numero"));
                    do{
                        numero2=Double.parseDouble(JOptionPane.showInputDialog("ingrese el segundo numero"));
                    }while(numero2 == 0);
                    resultado=numero1/numero2;
                    JOptionPane.showMessageDialog(null,"el resultado es:"+ resultado);
                    break;
                default:
                    break;
            }
            opcion=Integer.parseInt(JOptionPane.showInputDialog("elija una opcion \n 1-suma  \n 2-resta  \n 3-multiplicacion  \n 4-divicion \n 5-salir "));
            
        }
    }
    
}
